import UIKit

var str = "Hello, playground"

let saludon = "hola"

var otroSaludop = "Saludos"

let preguntaRespuesta = """
Q: Te gusta el pollo rostizado
A: Si me gusta el pollo rostizado!
"""

print(preguntaRespuesta)

let masSaludos = "este es un ejemplo de impresion de pantalla \\ \r \t \"Hola Mundo\""

print(masSaludos)

let myString = ""

if (myString.isEmpty){
    print("Esta cadena esta vacia")
}

let a = "a" //a es una cadena de caracteres
let b:Character = "b" //esto es solo un caracter

let string1 = "hello"
let string2 = ", World"

var myStringConcat = string1 + string2

print(myStringConcat)

myStringConcat += myStringConcat

print(myStringConcat)


//printf("nombre : %s tiene: %d", nombre, edad)/


let nombre = "jaasiel"
let edad = 22

print ("\(nombre) tienen \(edad)")

let c:Int = 5
let d:Int = 7

print("la suma de \(c) mas \(d) es \(c+d)")


