//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

let randomNum = arc4random_uniform(UInt32(5))

//bolaMagica()

//: [Next](@next)
