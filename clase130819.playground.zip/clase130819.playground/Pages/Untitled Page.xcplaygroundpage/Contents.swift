import UIKit

var str = "Hello, playground"

var personaFavorita = "MiPapá"

var noCalzado = 6.5

noCalzado = 10

personaFavorita = "miMamá"

var puntosOponente = 3 * 8

var misPuntos = 100 / 4

var puntosTotales = puntosOponente + misPuntos

let distanciaTotal = 2.5

var distanciaRecorrida = 1.7

var distanciaFaltante = distanciaTotal - distanciaRecorrida

print(distanciaFaltante)

let x:Double = 51
let y:Double = 4
let z = x/y
print(z)

misPuntos = 10

misPuntos = misPuntos + 1

misPuntos += 1
misPuntos -= 2

misPuntos *= 2
misPuntos /= 10

var a = 2
var b = 3
var c = 5

print(a + b * c)
print((a + b) * c)

let d = 3
let e = 0.1416
let pi = Double(d) + e

let f = 10
let g = 3

let h = Double(f) / Double(g)

print(h)







