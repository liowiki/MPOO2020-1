import UIKit

var str = "Hello, playground"

print(str)

2 + 2

print(2+2)

let nombre = "julio"

let pi = 3.1416

var edad = 15

edad = 25

print (edad)

print(nombre)

let 🐶 = "dog"

print(🐶)

let mañana = "viérnes"

print(mañana)

/*let nombreUsuario = "julio"
let edadUsuario = "31"
let delegacionTrabajoSabatino = "alvaro Obregon"*/

let myVar = "variable de ejemplo"

//esto es un comentario
//
//this is another comment
//
//let nombrePelicula = "El Rey Leon Live Action"
//let añoPelicula = 2019
//let director = "Dato desconocido"

let sumandoUno = 1
let sumandoDos:Int
let sumandoTres:Double
let sumandoCuatro = 1.50

sumandoDos = 7

let nombreJugador = "Rodrigo"
let puntajeJugador = 3000
//puntajeJugador = nombreJugador

var cosientePuntaje:Double = 23
//cosientePuntaje = 22.55
print(cosientePuntaje)

var jota = ""
jota = "letra j"

var ese:Character = "s"

//ese = "mi ese"

var x:Int

x=10

print(x)

struct Car {
    let marca:String
    let modelo:String
    let año:Int
}

Car.init(marca: "MClaren", modelo: "720S", año: 2020)










